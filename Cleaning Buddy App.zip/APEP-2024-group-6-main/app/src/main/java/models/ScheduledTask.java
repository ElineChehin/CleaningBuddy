package models;

import android.content.Context;
import android.widget.Toast;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.cleaningbuddy.R;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import database.Database;
import database.DateConverter;

@Entity(tableName = "scheduled_tasks", foreignKeys = {
        @ForeignKey(entity = Task.class, parentColumns = "id", childColumns = "taskId", onDelete = ForeignKey.CASCADE),
        @ForeignKey(entity = User.class, parentColumns = "id", childColumns = "completedBy", onDelete = ForeignKey.CASCADE)
})
public class ScheduledTask {
    @PrimaryKey(autoGenerate = true)
    private int id;
    @TypeConverters({DateConverter.class})
    private Date scheduledAt = new Date();
    private boolean isCompleted;
    @TypeConverters({DateConverter.class})
    private Date completedAt;
    private int taskId;
    private Integer completedBy;

    public ScheduledTask() {}

    public ScheduledTask(boolean isCompleted, Date scheduledAt, Date completedAt, int taskId, Integer completedBy) {
        this.isCompleted = isCompleted;
        this.scheduledAt = scheduledAt;
        this.completedAt = completedAt;
        this.taskId = taskId;
        this.completedBy = completedBy;
    }

    public ScheduledTask(int taskId) {
        this.taskId = taskId;
        this.scheduledAt = new Date();
        this.isCompleted = false;
        this.completedAt = null;
        this.completedBy = null;
    }

    public int getId() {
        return id;
    }

    public boolean getIsCompleted() {
        return isCompleted;
    }

    public Date getCompletedAt() {
        return completedAt;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setIsCompleted(boolean isCompleted) {
        this.isCompleted = isCompleted;
    }

    public void setCompletedAt(Date completedAt) {
        this.completedAt = completedAt;
    }

    public Date getScheduledAt() {
        return scheduledAt;
    }

    public void setScheduledAt(Date scheduledAt) {
        this.scheduledAt = scheduledAt;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public Integer getCompletedBy() {
        return completedBy;
    }

    public void setCompletedBy(Integer completedBy) {
        this.completedBy = completedBy;
    }

    public Task getTask(Context context){
        return Database.getDatabase(context).taskDao().getById(taskId);
    }

    public User getCompletedByUser(Context context){
        if (completedBy == null){
            return null;
        }
        return Database.getDatabase(context).userDao().getById(completedBy);
    }

    public static void add(Context context, ScheduledTask scheduledTask){
        if (scheduledTask != null){
            int id = (int) Database.getDatabase(context).scheduledTaskDao().insert(scheduledTask);
            scheduledTask.setId(id);
        }
    }

    public static List<ScheduledTask> getAll(Context context){
        return Database.getDatabase(context).scheduledTaskDao().getAll();
    }

    public static List<ScheduledTask> search(Context context, String name, boolean isCompleted){
        List<Task> tasks = Task.search(context, name);
        List<Integer> taskIds = new ArrayList<>();
        for (Task task : tasks){
            taskIds.add(task.getId());
        }
        return getByTaskIds(context, taskIds, isCompleted);
    }

    public static List<ScheduledTask> searchForRoom(Context context, String name, int roomId, boolean isCompleted){
        List<Task> tasks = Task.searchForRoom(context, roomId, name);
        List<Integer> taskIds = new ArrayList<>();
        for (Task task : tasks){
            taskIds.add(task.getId());
        }
        return getByTaskIds(context, taskIds, isCompleted);
    }

    public static List<ScheduledTask> searchForUser(Context context, String name, int userId, boolean isCompleted){
        List<Task> tasks = Task.searchForUser(context, userId, name);
        List<Integer> taskIds = new ArrayList<>();
        for (Task task : tasks){
            taskIds.add(task.getId());
        }
        return getByTaskIds(context, taskIds, isCompleted);
    }

    public static List<ScheduledTask> getByTaskIds(Context context, List<Integer> taskIds, boolean isCompleted){
        return Database.getDatabase(context).scheduledTaskDao().getByTaskIds(taskIds, isCompleted);
    }

    public void complete(Context context){
        isCompleted = true;
        completedAt = new Date();
        completedBy = User.getCurrentUser().getId();
        Database.getDatabase(context).scheduledTaskDao().update(this);
        Toast.makeText(context, R.string.taskCompleted_toast_id, Toast.LENGTH_SHORT).show();
    }
}

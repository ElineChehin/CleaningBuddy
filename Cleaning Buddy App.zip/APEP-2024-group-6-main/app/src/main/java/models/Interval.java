package models;

import android.content.Context;
import com.example.cleaningbuddy.R;
import java.util.ArrayList;
import java.util.List;

public class Interval {

    private String text;
    private int days;
    private static List<Interval> intervals;

    public Interval(String text, int days) {
        this.text = text;
        this.days = days;
    }

    public String getText() {
        return text;
    }

    public int getDays() {
        return days;
    }

    public static List<Interval> getAll(Context context) {
        if (intervals == null) {
            intervals = new ArrayList<>();
            intervals.add(new Interval(context.getString(R.string.createTask_interval_1), 1));
            intervals.add(new Interval(context.getString(R.string.createTask_interval_7), 7));
            intervals.add(new Interval(context.getString(R.string.createTask_interval_14), 14));
            intervals.add(new Interval(context.getString(R.string.createTask_interval_30), 30));
            intervals.add(new Interval(context.getString(R.string.createTask_customInterval_tv_id), 0));
        }
        return intervals;
    }

    @Override
    public String toString() {
        return text;
    }

    public static Interval getByDays(Context context, int days) {
        List<Interval> allIntervals = getAll(context);
        for (Interval interval : allIntervals) {
            if (interval.getDays() == days) {
                return interval;
            }
        }
        // custom if not found
        return allIntervals.get(allIntervals.size() - 1);
    }
}
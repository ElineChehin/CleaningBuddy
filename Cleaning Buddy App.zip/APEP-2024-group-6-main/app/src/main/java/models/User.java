package models;

import android.content.Context;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.util.List;

import database.Database;
import validation.PasswordValidator;

@Entity(tableName = "users")
public class User {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String username;
    private String password;

    @Ignore
    private static User currentUser;

    public User() {}

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public static void addUser(Context context, User user){
        if (user != null){
            Database.getDatabase(context).userDao().insert(user);
        }
    }

    public static boolean doesUserExist(Context context, String username) {
        User user = getUserFromDb(context, username);
        return user != null;
    }

    public static boolean validatePassword(Context context, String username, String providedPassword) {
       User user = getUserFromDb(context, username);
       String actualPassword = user.getPassword();

       return PasswordValidator.validatePassword(providedPassword, actualPassword);
    }

    public static User getUserFromDb(Context context, String username) {
        return Database.getDatabase(context).userDao().getByUsername(username);
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public static List<User> getAll(Context context){
        return Database.getDatabase(context).userDao().getAll();
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User currentUser) {
        User.currentUser = currentUser;
    }

    public static User getById(Context context, int id) {
        return Database.getDatabase(context).userDao().getById(id);
    }


    public String toString() {
        return username;
    }
}

package models;

import android.content.Context;

import database.Database;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.Date;
import java.util.List;

import database.DateConverter;

@Entity(tableName = "tasks", foreignKeys = {
        @ForeignKey(entity = Room.class, parentColumns = "id", childColumns = "roomId", onDelete = ForeignKey.SET_NULL),
        @ForeignKey(entity = User.class, parentColumns = "id", childColumns = "userId", onDelete = ForeignKey.SET_NULL)
})
public class Task {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String name;
    @TypeConverters({DateConverter.class})
    private Date lastScheduled;
    private int interval;
    private String description;
    private int roomId;
    private Integer userId;

    public Task() {
    }

    public Task(String name, Date lastScheduled, int interval, String description, int roomId, Integer userId) {
        this.name = name;
        this.lastScheduled = lastScheduled;
        this.interval = interval;
        this.description = description;
        this.roomId = roomId;
        this.userId = userId;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Date getLastScheduled() {
        return lastScheduled;
    }

    public int getInterval() {
        return interval;
    }

    public String getDescription() {
        return description;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLastScheduled(Date lastScheduled) {
        this.lastScheduled = lastScheduled;
    }

    public void setInterval(int interval) {
        this.interval = interval;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public User getUser(Context context) {
        if (userId == null) {
            return null;
        }
        return Database.getDatabase(context).userDao().getById(userId);
    }

    public Room getRoom(Context context) {
        return Database.getDatabase(context).roomDao().getById(roomId);
    }

    public static void add(Context context, Task task) {
        if (task != null) {
            int id = (int) Database.getDatabase(context).taskDao().insert(task);
            task.setId(id);
            task.schedule(context);
        }
    }

    public static List<Task> search(Context context, String name) {
        return Database.getDatabase(context).taskDao().search(name);
    }

    public static List<Task> searchForRoom(Context context, int roomId, String name) {
        return Database.getDatabase(context).taskDao().searchForRoom(roomId, name);
    }

    public static List<Task> searchForUser(Context context, int userId, String name) {
        return Database.getDatabase(context).taskDao().searchForUser(userId, name);
    }

    public static List<Task> getAll(Context context) {
        return Database.getDatabase(context).taskDao().getAll();
    }

    public static Task getById(Context context, int id) {
        return Database.getDatabase(context).taskDao().getById(id);
    }

    public static void scheduleTasks(Context context) {
        List<Task> tasks = Task.getAll(context);
        for (Task task : tasks) {
            if (task.shouldSchedule()) {
                task.schedule(context);
            }
        }
    }

    public void schedule(Context context) {
        ScheduledTask scheduledTask = new ScheduledTask(this.getId());
        ScheduledTask.add(context, scheduledTask);
        this.setLastScheduled(new Date());
        Database.getDatabase(context).taskDao().update(this);
    }

    public boolean shouldSchedule() {
        if (lastScheduled == null) {
            return true;
        }
        Date now = new Date();
        long diff = now.getTime() - lastScheduled.getTime();
        long diffDays = diff / (24 * 60 * 60 * 1000);
        return diffDays >= interval;
    }

    public static void update(Context context, Task task) {
        Database.getDatabase(context).taskDao().update(task);
    }

    public static void delete(Context context, Task task) {
        Database.getDatabase(context).taskDao().delete(task);
    }
    @Override
    public String toString() {
        return getName();
    }
}



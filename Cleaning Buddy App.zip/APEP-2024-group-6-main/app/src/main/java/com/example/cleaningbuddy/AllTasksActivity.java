package com.example.cleaningbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import adapters.AllTasksAdapter;
import models.ScheduledTask;

public class AllTasksActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SearchView searchView;
    private TextView notFoundTv;
    private List<ScheduledTask> tasks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_all_tasks);

        tasks = ScheduledTask.getAll(this);
        recyclerView = findViewById(R.id.allTasks_list_rv_id);
        searchView = findViewById(R.id.allTasks_search_sv_id);
        notFoundTv = findViewById(R.id.allTasks_noTaskFound_tv_id);

        AllTasksAdapter adapter = new AllTasksAdapter(tasks);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        updateTasks("");

        setupListeners();
    }

    private void setupListeners() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                updateTasks(query);
                return false;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        tasks.clear();
        tasks.addAll(ScheduledTask.search(this, "", false));
        recyclerView.getAdapter().notifyDataSetChanged();
    }

    public void updateTasks(String search){
        List<ScheduledTask> foundTasks = ScheduledTask.search(this, search, false);
        tasks.clear();
        if (foundTasks.isEmpty()){
            notFoundTv.setVisibility(View.VISIBLE);
        } else {
            notFoundTv.setVisibility(View.GONE);
        }
        tasks.addAll(foundTasks);
        recyclerView.getAdapter().notifyDataSetChanged();
    }

    public void goToHomeActivity(View view){
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    public void goToCreateTaskActivity(View view){
        Intent intent = new Intent(this, CreateTaskActivity.class);
        startActivity(intent);
    }
}
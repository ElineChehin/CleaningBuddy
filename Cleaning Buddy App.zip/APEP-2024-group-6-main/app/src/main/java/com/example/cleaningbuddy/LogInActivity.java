package com.example.cleaningbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import models.User;
import validation.StringValidator;

public class LogInActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_log_in);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void goToHomeActivity(View view){
        EditText userNameEditText = findViewById(R.id.logIn_username_pt_id);
        String userNameInput = userNameEditText.getText().toString();

        EditText userPasswordEditText = findViewById(R.id.logIn_password_et_id);
        String providedPassword = userPasswordEditText.getText().toString();

        if (!usernameNotEmpty(userNameInput)) return;
        if (!userExist(userNameInput)) return;
        if (!passwordNotEmpty(providedPassword)) return;
        if (!validatePassWord(userPasswordEditText, userNameInput, providedPassword)) return;

        User.setCurrentUser(User.getUserFromDb(this, userNameInput));

        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    private boolean usernameNotEmpty(String username) {
        if (!StringValidator.isNotNullOrEmpty(username)) {
            showToast(getString(R.string.nameEmpty_toast_id));
            return false;
        }
        return true;
    }

    private boolean passwordNotEmpty(String password) {
        if (!StringValidator.isNotNullOrEmpty(password)) {
            showToast(getString(R.string.passwordEmpty_toast_id));
            return false;
        }
        return true;
    }

    private boolean validatePassWord(EditText passwordEditText, String username,
                                     String providedPassword) {
        boolean validPassword = User.validatePassword( this, username, providedPassword);
        if (!validPassword) {
            showToast(getString(R.string.wrongPassword_toast_id));
            passwordEditText.setText("");
        }
        return validPassword;
    }

    private boolean userExist(String username) {
        boolean exists = User.doesUserExist(this, username);

        if (!exists) {
            showToast(getString(R.string.userNotFound_toast_id));
        }
        return exists;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public void goToSignUpActivity(View view){
        Intent intent = new Intent(this, SignUpActivity.class);
        startActivity(intent);
    }
}
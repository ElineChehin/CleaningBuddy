package com.example.cleaningbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

import models.Interval;
import models.Room;
import models.Task;
import models.User;
import validation.StringValidator;

public class CreateTaskActivity extends AppCompatActivity {
    private static List<Interval> intervals;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_task);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        intervals = Interval.getAll(this);
        intervalSpinner();

        // Assign To Room Spinner
        Spinner spinnerRoom = findViewById(R.id.createTask_roomSpinner_spn_id);
        ArrayAdapter<Room> adapterRoom = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                Room.getAll(this));
        spinnerRoom.setAdapter(adapterRoom);

        // Assign To User Spinner
        Spinner spinnerUser = findViewById(R.id.createTask_userSpinner_spn_id);
        List<User> userList = User.getAll(this);

        // Create a new User object representing "No user"
        User noUser = new User();
        noUser.setId(-1); // Use a unique ID that doesn't conflict with actual user IDs
        String noUserString = getString(R.string.createTask_noUser_id);
        noUser.setUsername(noUserString);
        userList.add(0, noUser);

        ArrayAdapter<User> adapterUser = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                userList);
        spinnerUser.setAdapter(adapterUser);
    }

    private void intervalSpinner() {
        Spinner spinnerInterval = findViewById(R.id.createTask_intervalSpinner_spn_id);
        ArrayAdapter<Interval> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, intervals);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerInterval.setAdapter(adapter);

        // Get references to the TextViews and EditText for custom interval
        TextView customIntervalTV = findViewById(R.id.createTask_customInterval_tv_id);
        TextView customIntervalDaysTV = findViewById(R.id.createTask_days_tv_id);
        EditText customIntervalInput = findViewById(R.id.createTask_customDays_pt_id);

        // Initially hide the custom interval views
        customIntervalTV.setVisibility(View.GONE);
        customIntervalDaysTV.setVisibility(View.GONE);
        customIntervalInput.setVisibility(View.GONE);

        setUpListeners(spinnerInterval, customIntervalTV, customIntervalDaysTV, customIntervalInput);
    }

    private void setUpListeners(Spinner spinnerInterval, TextView customIntervalTV, TextView customIntervalDaysTV, EditText customIntervalInput) {
        // Handle Spinner item selection
        spinnerInterval.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Interval selectedInterval = (Interval) parent.getItemAtPosition(position);
                if (selectedInterval.getText().equals(getString(R.string.createTask_customInterval_tv_id))) {
                    customIntervalTV.setVisibility(View.VISIBLE);
                    customIntervalDaysTV.setVisibility(View.VISIBLE);
                    customIntervalInput.setVisibility(View.VISIBLE);
                } else {
                    customIntervalTV.setVisibility(View.GONE);
                    customIntervalDaysTV.setVisibility(View.GONE);
                    customIntervalInput.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do something if nothing is selected
            }
        });
    }

    public void goToHomeActivity(View view) {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    public void save(View view) {
        // Name
        EditText nameET = findViewById(R.id.createTask_name_pt_id);
        String nameString = nameET.getText().toString();

        // Name Validation
        if (!StringValidator.isNotNullOrEmpty(nameString)) {
            Toast.makeText(this, getString(R.string.nameEmpty_toast_id), Toast.LENGTH_SHORT).show();
            return;
        }
        if (!StringValidator.isLengthBetween(nameString, 1, 30)) {
            Toast.makeText(this, getString(R.string.nameLength_toast_id), Toast.LENGTH_SHORT).show();
            return;
        }

        // Description
        EditText descriptionET = findViewById(R.id.createTask_description_pt_id);
        String descriptionString = descriptionET.getText().toString();

        // Description Validation
        if (!StringValidator.isLengthBetween(descriptionString, 0, 150)) {
            Toast.makeText(this, getString(R.string.descriptionLength_toast_id), Toast.LENGTH_SHORT).show();
            return;
        }

        // Interval
        int interval = getInterval();

        // Room ID
        Spinner spinnerRoom = findViewById(R.id.createTask_roomSpinner_spn_id);
        Room selectedRoom = (Room) spinnerRoom.getSelectedItem();

        if (selectedRoom == null) {
            Toast.makeText(this, getString(R.string.createTask_selectRoom_toast), Toast.LENGTH_SHORT).show();
            return;
        }
        int roomId = selectedRoom.getId();

        // User ID
        Spinner spinnerUser = findViewById(R.id.createTask_userSpinner_spn_id);
        User selectedUser = (User) spinnerUser.getSelectedItem();
        Integer userId;

        if (selectedUser != null && selectedUser.getId() != -1) {
            userId = selectedUser.getId();
        } else {
            userId = null;
        }

        Task task = new Task(nameString, null, interval, descriptionString, roomId, userId);
        Task.add(this, task);
        finish();

    }

    private int getInterval() {
        // Standard Interval
        Spinner spinnerInterval = findViewById(R.id.createTask_intervalSpinner_spn_id);
        Interval selectedInterval = (Interval) spinnerInterval.getSelectedItem();

        // Input Custom Interval
        EditText intervalET = findViewById(R.id.createTask_customDays_pt_id);
        int interval;

        // Determine the interval value
        if (selectedInterval.getText().equals(getString(R.string.createTask_customInterval_tv_id))) {
            interval = Integer.parseInt(intervalET.getText().toString());
        } else {
            interval = selectedInterval.getDays();
        }

        return interval;
    }

    public void finish(View view) {
        finish();
    }
}
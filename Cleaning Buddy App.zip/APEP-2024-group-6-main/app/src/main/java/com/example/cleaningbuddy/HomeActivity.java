package com.example.cleaningbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import models.User;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        User currentUser = User.getCurrentUser();
        if (currentUser != null) {
            String username = currentUser.getUsername();
            TextView showUserName = findViewById(R.id.home_hiUser_tv_id);
            String helloStr = getString(R.string.home_hiUser_tv_id);

            showUserName.setText(String.format(helloStr, username));
        }
    }

    public void goToCreateRoomActivity(View view){
        Intent intent = new Intent(this, CreateRoomActivity.class);
        startActivity(intent);
    }

    public void goToEditRoomActivity(View view){
        Intent intent = new Intent(this, EditRoomActivity.class);
        startActivity(intent);
    }

    public void goToRoomsActivity(View view){
        Intent intent = new Intent(this, AllRoomsActivity.class);
        startActivity(intent);
    }

    public void goToCreateTaskActivity(View view){
        Intent intent = new Intent(this, CreateTaskActivity.class);
        startActivity(intent);
    }

    public void goToEditTaskActivity(View view){
        Intent intent = new Intent(this, EditTaskActivity.class);
        startActivity(intent);
    }

    public void goToMyTasksActivity(View view){
        Intent intent = new Intent(this, MyTasksActivity.class);
        startActivity(intent);
    }

    public void goToAllTasksActivity(View view){
        Intent intent = new Intent(this, AllTasksActivity.class);
        startActivity(intent);
    }

    public void goToStartActivity(View view){
        User.setCurrentUser(null);
        Intent intent = new Intent(this, StartActivity.class);
        startActivity(intent);
    }
}
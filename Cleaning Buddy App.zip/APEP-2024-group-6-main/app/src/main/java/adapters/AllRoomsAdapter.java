package adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cleaningbuddy.EditRoomActivity;
import com.example.cleaningbuddy.R;
import com.example.cleaningbuddy.TasksPerRoomActivity;

import java.util.List;

import models.Room;

public class AllRoomsAdapter extends RecyclerView.Adapter<AllRoomsAdapter.ViewHolder> {
    private List<Room> data;

    public AllRoomsAdapter(List<Room> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.allrooms_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Context context = holder.itemView.getContext();
        Room roomID = data.get(position);
        holder.roomIdTv.setText(String.valueOf(roomID.getId()));

        Room roomName = data.get(position);
        holder.roomNameTv.setText(roomName.getName());

        Room room = data.get(position);

        holder.editBtn.setOnClickListener(view -> {

            Intent intent = new Intent(context, EditRoomActivity.class);
            intent.putExtra("roomId", room.getId());
            context.startActivity(intent);
        });

        holder.itemView.setOnClickListener(view -> {
            int roomId = room.getId();
            Intent intent = new Intent(context, TasksPerRoomActivity.class);
            intent.putExtra("roomId", roomId);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView roomIdTv;
        private TextView roomNameTv;
        private Button editBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            roomIdTv = itemView.findViewById(R.id.allRoomsRow_roomId_tv);
            roomNameTv = itemView.findViewById(R.id.allRoomsRow_roomName_tv);
            editBtn = itemView.findViewById(R.id.allRoomsRow_edit_btn_id);
        }
    }
}

package dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import models.Room;

@Dao
public interface RoomDao {
    @Query("SELECT * FROM rooms")
    List<Room> getAll();

    @Query("SELECT * FROM rooms WHERE id = :id")
    Room getById(int id);

    @Query("SELECT * FROM rooms WHERE LOWER(name) LIKE '%' || LOWER(:name) || '%'")
    List<Room> search(String name);

    @Insert
    void insert(Room room);

    @Update
    void update(Room room);

    @Delete
    void delete(Room room);
}

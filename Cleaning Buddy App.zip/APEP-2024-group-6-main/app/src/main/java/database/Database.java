package database;

import android.content.Context;

import androidx.room.RoomDatabase;

import dao.RoomDao;
import dao.ScheduledTaskDao;
import dao.TaskDao;
import dao.UserDao;
import models.Room;
import models.ScheduledTask;
import models.Task;
import models.User;

@androidx.room.Database(entities = {Room.class, Task.class, User.class, ScheduledTask.class}, version = 4, exportSchema = false)
public abstract class Database extends RoomDatabase {
    public abstract RoomDao roomDao();
    public abstract TaskDao taskDao();
    public abstract UserDao userDao();
    public abstract ScheduledTaskDao scheduledTaskDao();

    public static Database getDatabase(Context context) {
        Database database;
        synchronized (Database.class) {
            database = androidx.room.Room.databaseBuilder(context, Database.class, "CleaningBuddyDB")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries().build();
        }
        return database;
    }
}

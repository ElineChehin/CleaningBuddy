package validation;

public class StringValidator {

    public static boolean StringInputNotEqual(String input1, String input2) {
        return !(input1.equalsIgnoreCase(input2));
    }

    public static boolean isNotNullOrEmpty(String string) {
        return string != null && !string.isEmpty();
    }

    public static boolean isLengthBetween(String string, int min, int max) {
        if (string == null) {
            return false;
        }
        if (min != -1 && string.length() < min) {
            return false;
        }

        if (max != -1 && string.length() > max) {
            return false;
        }
        return true;
    }

    public static boolean isAlphaNumeric(String string) {
        if (string == null) {
            return false;
        }
        return string.matches("^[a-zA-Z0-9]*$");
    }
}

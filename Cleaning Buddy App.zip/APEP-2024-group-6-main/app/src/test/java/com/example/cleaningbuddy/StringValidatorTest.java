package com.example.cleaningbuddy;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import validation.StringValidator;

public class StringValidatorTest {
    @Test
    public void StringValidator_isNotNullOrEmpty() {
        assertTrue(StringValidator.isNotNullOrEmpty("Hello"));
        assertFalse(StringValidator.isNotNullOrEmpty(""));
        assertFalse(StringValidator.isNotNullOrEmpty(null));
    }

    @Test
    public void StringValidator_isLengthBetween() {
        assertTrue(StringValidator.isLengthBetween("TestString", 1, 10));
        assertTrue(StringValidator.isLengthBetween("ABC", 1, 10));
        assertFalse(StringValidator.isLengthBetween("strings", 1, 5));
        assertFalse(StringValidator.isLengthBetween("xx", 3, 10));
    }

    @Test
    public void StringValidator_isAlphaNumeric() {
        assertTrue(StringValidator.isAlphaNumeric("strings123"));
        assertTrue(StringValidator.isAlphaNumeric("123"));
        assertTrue(StringValidator.isAlphaNumeric("abc"));
        assertFalse(StringValidator.isAlphaNumeric("!##."));
        assertFalse(StringValidator.isAlphaNumeric("abc.123"));
        assertFalse(StringValidator.isAlphaNumeric("string "));
    }
}

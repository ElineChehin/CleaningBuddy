package com.example.cleaningbuddy;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import validation.PasswordValidator;

public class EncryptPasswordTest {
    @Test
    public void testEncryptPassword() {
        String password = "password";
        String encryptedPassword = PasswordValidator.hashPassword(password);

        String passwordAttempt1 = "password";
        String passwordAttempt2 = "welcome123";

        assertTrue(PasswordValidator.validatePassword(passwordAttempt1, encryptedPassword));
        assertFalse(PasswordValidator.validatePassword(passwordAttempt2, encryptedPassword));
    }
}

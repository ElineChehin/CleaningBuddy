package com.example.cleaningbuddy;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import models.Task;

public class TaskScheduleTest {
    @Test
    public void Task_shouldSchedule() {
        Task task = new Task("ABC", null, 1, "Test task", 1, null);
        // should schedule when not been scheduled before
        assertTrue(task.shouldSchedule());

        task.setLastScheduled(new java.util.Date(System.currentTimeMillis() - 1000 * 60 * 60 * 25));
        // should schedule when last scheduled more than interval days ago
        assertTrue(task.shouldSchedule());

        task.setLastScheduled(new java.util.Date(System.currentTimeMillis() - 1000 * 60 * 60 * 23));
        // should not schedule when last scheduled less than interval days ago
        assertFalse(task.shouldSchedule());
    }
}

package adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cleaningbuddy.MyTasksActivity;
import com.example.cleaningbuddy.R;
import com.example.cleaningbuddy.TaskHistoryActivity;

import java.util.Date;
import java.util.List;

import formatters.DateFormatter;
import models.ScheduledTask;
import models.Task;
import models.User;

public class MyTasksAdapter extends RecyclerView.Adapter<MyTasksAdapter.ViewHolder>{

    private List<ScheduledTask> data;
    public MyTasksAdapter(List<ScheduledTask> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.mytasks_row, parent, false);
        return new MyTasksAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Context context = holder.itemView.getContext();
        ScheduledTask scheduledTask = data.get(position);
        Task task = scheduledTask.getTask(context);

        Date scheduledDate = scheduledTask.getScheduledAt();
        String formattedDate = DateFormatter.formatToDateTime(scheduledDate);
        holder.scheduledDateTv.setText(formattedDate);

        User user = task.getUser(context);

        if (user != null) {
            holder.assignedUserTv.setText(String.valueOf(user.getUsername()));
        } else {
            holder.assignedUserTv.setText(R.string.NoUserSelected_placeholder);
        }

        holder.taskNameTv.setText(String.valueOf(task.getName()));

        // handle completion of task
        holder.completedCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                scheduledTask.complete(context);
            }
            // reload task view
            ((MyTasksActivity) context).updateTasks("");
            holder.completedCheckBox.setChecked(false);
        });

        // make task clickable
        holder.itemView.setOnClickListener(view -> {
            int taskId = task.getId();
            Intent intent = new Intent(context, TaskHistoryActivity.class);
            intent.putExtra("taskId", taskId);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView taskNameTv;
        private TextView assignedUserTv;
        private TextView assignedRoomTv;
        private CheckBox completedCheckBox;

        private TextView scheduledDateTv;

        public ViewHolder(View itemView) {
            super(itemView);
            taskNameTv = itemView.findViewById(R.id.myTasksRow_name_tv_id);
            assignedUserTv = itemView.findViewById(R.id.myTasksRow_user_tv_id);
            assignedRoomTv = itemView.findViewById(R.id.myTasksRow_room_tv_id);
            completedCheckBox = itemView.findViewById(R.id.myTasksRow_done_chk_id);
            scheduledDateTv = itemView.findViewById(R.id.myTasksRow_date_tv_id);

        }
    }
}
package adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cleaningbuddy.R;

import java.util.Date;
import java.util.List;

import formatters.DateFormatter;
import models.ScheduledTask;
import models.User;

public class TaskHistoryAdapter extends RecyclerView.Adapter<TaskHistoryAdapter.ViewHolder> {
    private List<ScheduledTask> data;

    public TaskHistoryAdapter(List<ScheduledTask> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.taskhistory_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Context context = holder.itemView.getContext();
        ScheduledTask task = data.get(position);
        User completedBy = task.getCompletedByUser(context);
        String completedByName = "No user";
        if (completedBy != null) {
            completedByName = completedBy.toString();
        }
        holder.userNameTv.setText(completedByName);
        Date completedDate = task.getCompletedAt();
        String formattedDate = DateFormatter.formatToDateTime(completedDate);
        holder.completedDateTv.setText(formattedDate);
    }

    @Override
    public int getItemCount() {

        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView userNameTv;
        private TextView completedDateTv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            userNameTv = itemView.findViewById(R.id.TaskHistoryRow_user_tv);
            completedDateTv = itemView.findViewById(R.id.TaskHistoryRow_completedAt_tv);
        }
    }
}

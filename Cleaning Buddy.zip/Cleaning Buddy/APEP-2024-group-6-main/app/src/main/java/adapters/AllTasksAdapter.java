package adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cleaningbuddy.AllTasksActivity;
import com.example.cleaningbuddy.R;
import com.example.cleaningbuddy.TaskHistoryActivity;

import java.util.Date;
import java.util.List;

import formatters.DateFormatter;
import models.Room;
import models.ScheduledTask;
import models.Task;
import models.User;

public class AllTasksAdapter extends RecyclerView.Adapter<AllTasksAdapter.ViewHolder>{

    private List<ScheduledTask> data;

    public AllTasksAdapter(List<ScheduledTask> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public AllTasksAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.alltasks_row, parent, false);
        return new AllTasksAdapter.ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Context context = holder.itemView.getContext();
        ScheduledTask scheduledTask = data.get(position);
        Task task = scheduledTask.getTask(context);

        Date scheduledDate = scheduledTask.getScheduledAt();
        String formattedDate = DateFormatter.formatToDateTime(scheduledDate);
        holder.scheduledDateTv.setText(formattedDate);

        User user = task.getUser(context);
        Room room = task.getRoom(context);

        if (user != null) {
            holder.assignedUserTv.setText(String.valueOf(user.getUsername()));
        } else {
            holder.assignedUserTv.setText(R.string.NoUserSelected_placeholder);
        }
        if (room != null) {
            holder.assignedRoomTv.setText(String.valueOf(room.getName()));
        } else {
            holder.assignedRoomTv.setText(R.string.NoRoomSelected_placeholder);
        }

        holder.taskNameTv.setText(String.valueOf(task.getName()));

        // handle completion of task
        holder.completedCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                scheduledTask.complete(context);
            }
            // reload task view
            ((AllTasksActivity) context).updateTasks("");
            holder.completedCheckBox.setChecked(false);
        });

        // make task clickable
        holder.itemView.setOnClickListener(view -> {
            int taskId = task.getId();
            Intent intent = new Intent(context, TaskHistoryActivity.class);
            intent.putExtra("taskId", taskId);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView taskNameTv;
        private TextView assignedRoomTv;
        private TextView assignedUserTv;
        private TextView scheduledDateTv;
        private CheckBox completedCheckBox;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            taskNameTv = itemView.findViewById(R.id.allTasksRow_name_tv);
            assignedRoomTv = itemView.findViewById(R.id.allTasksRow_room_tv);
            assignedUserTv = itemView.findViewById(R.id.allTasksRow_user_tv);
            scheduledDateTv = itemView.findViewById(R.id.allTasksRow_date_tv);
            completedCheckBox = itemView.findViewById(R.id.allTasksRow_completed_chk);
        }
    }
}
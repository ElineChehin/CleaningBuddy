package dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import models.Task;

@Dao
public interface TaskDao {
    @Query("SELECT * FROM tasks")
    List<Task> getAll();

    @Query("SELECT * FROM tasks WHERE id = :id")
    Task getById(int id);

    @Query("SELECT * FROM tasks WHERE LOWER(name) LIKE '%' || LOWER(:name) || '%'")
    List<Task> search(String name);

    @Query("SELECT * FROM tasks WHERE roomId = :roomId AND LOWER(name) LIKE '%' || LOWER(:name) || '%'")
    List<Task> searchForRoom(int roomId, String name);

    @Query("SELECT * FROM tasks WHERE (userId = :userId OR userId IS NULL) AND LOWER(name) LIKE '%' || LOWER(:name) || '%'")
    List<Task> searchForUser(int userId, String name);

    @Insert
    long insert(Task room);

    @Update
    void update(Task room);

    @Delete
    void delete(Task room);
}

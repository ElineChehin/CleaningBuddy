package dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import models.ScheduledTask;

@Dao
public interface ScheduledTaskDao {
    @Query("SELECT * FROM scheduled_tasks")
    List<ScheduledTask> getAll();

    @Query("SELECT * FROM scheduled_tasks WHERE id = :id")
    ScheduledTask getById(int id);

    @Query("SELECT * FROM scheduled_tasks WHERE taskId IN (:taskIds) AND isCompleted = :isCompleted")
    List<ScheduledTask> getByTaskIds(List<Integer> taskIds, boolean isCompleted);

    @Insert
    long insert(ScheduledTask room);

    @Update
    void update(ScheduledTask room);

    @Delete
    void delete(ScheduledTask room);
}

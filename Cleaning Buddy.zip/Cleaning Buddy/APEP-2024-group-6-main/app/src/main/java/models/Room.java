package models;

import android.content.Context;
import java.util.List;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import database.Database;

@Entity(tableName = "rooms")

public class Room {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String name;

    public Room() {}

    public Room(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public static void add(Context context, Room room){
        if (room != null){
            Database.getDatabase(context).roomDao().insert(room);
        }
    }

    public static List<Room> getAll(Context context){
        return Database.getDatabase(context).roomDao().getAll();
    }
    public static List<Room> search(Context context, String name){
        return Database.getDatabase(context).roomDao().search(name);
    }


    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static Room getById(Context context, int id) {
        return Database.getDatabase(context).roomDao().getById(id);
    }


    @Override
    public String toString() {
        return getName();
    }
}

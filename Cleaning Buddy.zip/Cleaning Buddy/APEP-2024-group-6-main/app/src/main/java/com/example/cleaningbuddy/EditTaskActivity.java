package com.example.cleaningbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

import models.Interval;
import models.Room;
import models.Task;
import models.User;
import validation.StringValidator;

public class EditTaskActivity extends AppCompatActivity {
    private static List<Interval> intervals;
    private static List<Task> tasks;

    private Task selectedTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_task);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        intervals = Interval.getAll(this);
        intervalSpinner();

        // Assign To Room Spinner
        Spinner spinnerRoom = findViewById(R.id.editTask_assignedRoom_spnr_id);
        ArrayAdapter<Room> adapterRoom = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                Room.getAll(this));
        spinnerRoom.setAdapter(adapterRoom);

        // Assign To User Spinner
        Spinner spinnerUser = findViewById(R.id.editTask_assignedUser_spnr_id);
        List<User> userList = User.getAll(this);

        // Create a new User object representing "No user"
        User noUser = new User();
        noUser.setId(-1); // Use a unique ID that doesn't conflict with actual user IDs
        String noUserString = getString(R.string.createTask_noUser_id);
        noUser.setUsername(noUserString);
        userList.add(0, noUser);

        ArrayAdapter<User> adapterUser = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                userList);
        spinnerUser.setAdapter(adapterUser);

        // Task Spinner
        Spinner spinnerTask = findViewById(R.id.editTask_tasks_spnr_id);
        tasks = Task.getAll(this);
        ArrayAdapter<Task> adapterTask = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                tasks);
        spinnerTask.setAdapter(adapterTask);

        int taskId = getIntent().getIntExtra("taskId", -1);
        for (int i = 0; i < tasks.size(); i++) {
            Task task = tasks.get(i);
            if (task.getId() == taskId) {
                spinnerTask.setSelection(i);
                selectedTask = task;
                break;
            }
        }

        spinnerTask.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedTask = (Task) parent.getItemAtPosition(position);
                loadTaskDetails();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do something if nothing is selected
            }
        });
    }

    private void loadTaskDetails() {
        if (selectedTask != null) {
            EditText nameET = findViewById(R.id.editTask_name_pt_id);
            nameET.setText(selectedTask.getName());

            EditText descriptionET = findViewById(R.id.editTask_description_pt_id);
            descriptionET.setText(selectedTask.getDescription());

            Spinner intervalSpinner = findViewById(R.id.editTask_interval_spnr_id);
            ArrayAdapter<Interval> intervalAdapter = (ArrayAdapter<Interval>) intervalSpinner.getAdapter();
            Interval selectedInterval = Interval.getByDays(this, selectedTask.getInterval());
            intervalSpinner.setSelection(intervalAdapter.getPosition(selectedInterval));

            if (selectedInterval.getDays() == 0) {
                EditText customIntervalET = findViewById(R.id.editTask_customInterval_pt_id);
                customIntervalET.setText(String.valueOf(selectedTask.getInterval()));
            }

            Spinner roomSpinner = findViewById(R.id.editTask_assignedRoom_spnr_id);
            ArrayAdapter<Room> roomAdapter = (ArrayAdapter<Room>) roomSpinner.getAdapter();
            for (int i = 0; i < roomAdapter.getCount(); i++) {
                if (roomAdapter.getItem(i).getId() == selectedTask.getRoomId()) {
                    roomSpinner.setSelection(i);
                    break;
                }
            }

            Spinner userSpinner = findViewById(R.id.editTask_assignedUser_spnr_id);
            ArrayAdapter<User> userAdapter = (ArrayAdapter<User>) userSpinner.getAdapter();
            User user = selectedTask.getUserId() != null ? User.getById(this, selectedTask.getUserId()) : null;
            for (int i = 0; i < userAdapter.getCount(); i++) {
                if (userAdapter.getItem(i).getId() == user.getId()) {
                    userSpinner.setSelection(i);
                    break;
                }
            }
        }
    }

    private void intervalSpinner() {
        Spinner spinnerInterval = findViewById(R.id.editTask_interval_spnr_id);
        ArrayAdapter<Interval> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, intervals);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerInterval.setAdapter(adapter);

        // Get references to the TextViews and EditText for custom interval
        TextView customIntervalTV = findViewById(R.id.editTask_customInterval_tv_id);
        TextView customIntervalDaysTV = findViewById(R.id.editTask_days_tv_id);
        EditText customIntervalInput = findViewById(R.id.editTask_customInterval_pt_id);

        // Initially hide the custom interval views
        customIntervalTV.setVisibility(View.GONE);
        customIntervalDaysTV.setVisibility(View.GONE);
        customIntervalInput.setVisibility(View.GONE);

        setUpListeners(spinnerInterval, customIntervalTV, customIntervalDaysTV, customIntervalInput);
    }

    private void setUpListeners(Spinner spinnerInterval, TextView customIntervalTV, TextView customIntervalDaysTV, EditText customIntervalInput) {
        // Handle Spinner item selection
        spinnerInterval.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Interval selectedInterval = (Interval) parent.getItemAtPosition(position);
                if (selectedInterval.getText().equals(getString(R.string.createTask_customInterval_tv_id))) {
                    customIntervalTV.setVisibility(View.VISIBLE);
                    customIntervalDaysTV.setVisibility(View.VISIBLE);
                    customIntervalInput.setVisibility(View.VISIBLE);
                } else {
                    customIntervalTV.setVisibility(View.GONE);
                    customIntervalDaysTV.setVisibility(View.GONE);
                    customIntervalInput.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    public void goToHomeActivity(View view) {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    public void goToHistoryActivity(View view) {
        Intent intent = new Intent(this, TaskHistoryActivity.class);
        intent.putExtra("taskId", selectedTask.getId());
        startActivity(intent);
    }

    public void save(View view) {
        // Name
        EditText nameET = findViewById(R.id.editTask_name_pt_id);
        String nameString = nameET.getText().toString();

        // Name Validation
        if (!StringValidator.isNotNullOrEmpty(nameString)) {
            Toast.makeText(this, getString(R.string.nameEmpty_toast_id), Toast.LENGTH_SHORT).show();
            return;
        }
        if (!StringValidator.isLengthBetween(nameString, 1, 30)) {
            Toast.makeText(this, getString(R.string.nameLength_toast_id), Toast.LENGTH_SHORT).show();
            return;
        }

        // Description
        EditText descriptionET = findViewById(R.id.editTask_description_pt_id);
        String descriptionString = descriptionET.getText().toString();

        // Description Validation
        if (!StringValidator.isLengthBetween(descriptionString, 0, 150)) {
            Toast.makeText(this, getString(R.string.descriptionLength_toast_id), Toast.LENGTH_SHORT).show();
            return;
        }

        int interval = getInterval();

        // Room ID
        Spinner spinnerRoom = findViewById(R.id.editTask_assignedRoom_spnr_id);
        Room selectedRoom = (Room) spinnerRoom.getSelectedItem();

        if (selectedRoom == null) {
            Toast.makeText(this, getString(R.string.createTask_selectRoom_toast), Toast.LENGTH_SHORT).show();
            return;
        }
        int roomId = selectedRoom.getId();

        // User ID
        Spinner spinnerUser = findViewById(R.id.editTask_assignedUser_spnr_id);
        User selectedUser = (User) spinnerUser.getSelectedItem();
        Integer userId = selectedUser != null && selectedUser.getId() != -1 ? selectedUser.getId() : null;

        // Update Task
        selectedTask.setName(nameString);
        selectedTask.setDescription(descriptionString);
        selectedTask.setInterval(interval);
        selectedTask.setRoomId(roomId);
        selectedTask.setUserId(userId);

        Task.update(this, selectedTask);

        Toast.makeText(this, getString(R.string.editTask_savedSuccessfully_toast), Toast.LENGTH_SHORT).show();
        goToHomeActivity(view);
    }

    private int getInterval() {
        Spinner spinnerInterval = findViewById(R.id.editTask_interval_spnr_id);
        Interval selectedInterval = (Interval) spinnerInterval.getSelectedItem();
        int interval = selectedInterval.getDays();

        // Custom Interval
        if (selectedInterval.getText().equals(getString(R.string.createTask_customInterval_tv_id))) {
            EditText customIntervalET = findViewById(R.id.editTask_customInterval_pt_id);
            interval = Integer.parseInt(customIntervalET.getText().toString());
        }
        return interval;
    }

    public void delete(View view) {
        Task.delete(this, selectedTask);
        Toast.makeText(this, getString(R.string.editTask_deletedSuccessfully_toast), Toast.LENGTH_SHORT).show();
        finish();
    }

    public void finish(View view) {
        finish();
    }
}

package com.example.cleaningbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import adapters.AllRoomsAdapter;
import models.Room;

public class AllRoomsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SearchView searchView;
    private TextView notFoundTv;
    private List<Room> rooms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_all_rooms);

        rooms = Room.getAll(this);
        recyclerView = findViewById(R.id.allRooms_list_rv_id);
        searchView = findViewById(R.id.allRooms_search_sv_id);
        notFoundTv = findViewById(R.id.allRooms_not_found_tv_id);

        AllRoomsAdapter adapter = new AllRoomsAdapter(rooms);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        updateRooms("");
        setupListeners();
    }

    private void setupListeners() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
      
        rooms = Room.getAll(this);
        recyclerView = findViewById(R.id.allRooms_list_rv_id);
        AllRoomsAdapter adapter = new AllRoomsAdapter(rooms);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
      
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String query) {
                updateRooms(query);
                return false;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        rooms.clear();
        rooms.addAll(Room.getAll(this));
        recyclerView.getAdapter().notifyDataSetChanged();
    }

    public void goToHomeActivity(View view){
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    public void goToEditRoomActivity(View view){
        Intent intent = new Intent(this, EditRoomActivity.class);
        startActivity(intent);
    }

    public void goToCreateRoomActivity(View view){
        Intent intent = new Intent(this, CreateRoomActivity.class);
        startActivity(intent);
    }

    public void updateRooms(String search){
        List<Room> foundRooms = Room.search(this, search);
        rooms.clear();
        if (foundRooms.isEmpty()){
            notFoundTv.setVisibility(View.VISIBLE);
        } else {
            notFoundTv.setVisibility(View.GONE);
        }
        rooms.addAll(foundRooms);
        recyclerView.getAdapter().notifyDataSetChanged();
    }

    public void finish(View view){
        finish();
    }
}
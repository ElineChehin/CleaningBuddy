package com.example.cleaningbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

import database.Database;
import models.Room;
import validation.StringValidator;

public class EditRoomActivity extends AppCompatActivity {

    private Spinner roomSpinner;
    private EditText nameET;
    private Room selectedRoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_room);

        // get room id from intent
        int roomId = getIntent().getIntExtra("roomId", -1);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        roomSpinner = findViewById(R.id.editRoom_roomSpinner_spnr_id);
        nameET = findViewById(R.id.editRoom_newName_et_id);

        loadRooms();
        // set the spinner to the room that was selected
        for (int i = 0; i < roomSpinner.getCount(); i++) {
            Room room = (Room) roomSpinner.getItemAtPosition(i);
            if (room.getId() == roomId) {
                roomSpinner.setSelection(i);
                selectedRoom = room;
                nameET.setText(selectedRoom.getName());
                break;
            }
        }
        setupListeners();
    }

    private void setupListeners() {
        roomSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedRoom = (Room) parent.getItemAtPosition(position);
                nameET.setText(selectedRoom.getName());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedRoom = null;
                nameET.setText("");
            }
        });
    }

    private void loadRooms() {
        List<Room> rooms = Room.getAll(this);
        ArrayAdapter<Room> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, rooms);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        roomSpinner.setAdapter(adapter);
    }

    public void save(View view) {
        String nameString = nameET.getText().toString();

        // Validate the new room name
        if (!StringValidator.isNotNullOrEmpty(nameString)) {
            Toast.makeText(this, getString(R.string.nameEmpty_toast_id), Toast.LENGTH_SHORT).show();
            return;
        }
        if (!StringValidator.isLengthBetween(nameString, 1, 30)) {
            Toast.makeText(this, getString(R.string.nameLength_toast_id), Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedRoom != null) {
            selectedRoom.setName(nameString);

            // Save the updated room to the database
            Database.getDatabase(this).roomDao().update(selectedRoom);
            Toast.makeText(this, getString(R.string.roomUpdated_toast_id), Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, AllRoomsActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, getString(R.string.roomNotFound_toast_id), Toast.LENGTH_SHORT).show();
        }
    }

    public void delete(View view) {
        if (selectedRoom != null) {
            // Delete the room from the database
            Database.getDatabase(this).roomDao().delete(selectedRoom);
            Toast.makeText(this, getString(R.string.roomDeleted_toast_id), Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, AllRoomsActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, getString(R.string.roomNotFound_toast_id), Toast.LENGTH_SHORT).show();
        }
    }

    public void goToHomeActivity(View view) {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    public void finish(View view) {
        finish();
    }
}
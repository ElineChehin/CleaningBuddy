package com.example.cleaningbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import adapters.TasksPerRoomAdapter;
import models.Room;
import models.ScheduledTask;

public class TasksPerRoomActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SearchView searchView;
    private TextView notFoundTv;
    private List<ScheduledTask> scheduledTasks;
    private Room room;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        int roomId = getIntent().getIntExtra("roomId", -1);
        room = Room.getById(this, roomId);
        if (room == null) {
            Toast.makeText(this, R.string.roomNotFound_toast_id, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        setContentView(R.layout.activity_tasks_per_room);

        TextView roomName = findViewById(R.id.tasksPerRoom_title_tv_id);
        String roomText = getString(R.string.tasksPerRoom_title_tv_id);
        roomName.setText(String.format(roomText, room.getName()));

        scheduledTasks = ScheduledTask.searchForRoom(this, "",roomId, false);
        recyclerView = findViewById(R.id.tasksPerRoom_list_rv_id);
        searchView = findViewById(R.id.tasksPerRoom_search_sv_id);
        notFoundTv = findViewById(R.id.tasksPerRoom_no_tasks_current_room_found);

        TasksPerRoomAdapter tasksPerRoomAdapter = new TasksPerRoomAdapter(scheduledTasks);
        recyclerView.setAdapter(tasksPerRoomAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        updateTasks("");

        setupListeners();
    }

    private void setupListeners() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                updateTasks(query);
                return false;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        scheduledTasks.clear();
        scheduledTasks.addAll(ScheduledTask.searchForRoom(this, "", room.getId(), false));
        recyclerView.getAdapter().notifyDataSetChanged();
    }

    public void updateTasks(String search){
        List<ScheduledTask> foundTasks = ScheduledTask.searchForRoom(this, search, room.getId(), false);
        scheduledTasks.clear();
        if (foundTasks.isEmpty()){
            notFoundTv.setVisibility(View.VISIBLE);
        } else {
            notFoundTv.setVisibility(View.GONE);
        }
        scheduledTasks.addAll(foundTasks);
        recyclerView.getAdapter().notifyDataSetChanged();
    }

    public void goToHomeActivity(View view){
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    public void goToCreateTaskActivity(View view){
        Intent intent = new Intent(this, CreateTaskActivity.class);
        startActivity(intent);
    }

    public void finish(View view) {
        finish();
    }
}
package com.example.cleaningbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.List;

import adapters.TaskHistoryAdapter;
import models.ScheduledTask;
import models.Task;
import validation.StringValidator;

public class TaskHistoryActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private TextView taskName;
    private TextView taskDescription;
    private TextView notFoundTv;
    private List<ScheduledTask> tasks;
    private Task task;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_task_history);

        int taskId = getIntent().getIntExtra("taskId", -1);
        task = Task.getById(this, taskId);
        if (task == null) {
            Toast.makeText(this, R.string.taskNotFound_toast_id, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tasks = getTasks();

        taskName = findViewById(R.id.taskHistory_task_id);
        taskDescription = findViewById(R.id.taskHistory_description_id);
        recyclerView = findViewById(R.id.TaskHistory_list_rv_id);
        notFoundTv = findViewById(R.id.taskHistory_noTasks_tv_id);

        String taskText = getString(R.string.taskHistory_task_tv_id);
        taskName.setText(String.format(taskText, task.getName()));
        String descriptionText = getString(R.string.taskHistory_description_tv_id);

        if (StringValidator.isNotNullOrEmpty(task.getDescription())) {
            taskDescription.setText(String.format(descriptionText, task.getDescription()));
        } else {
            taskDescription.setText("");
        }
        TaskHistoryAdapter adapter = new TaskHistoryAdapter(tasks);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        updateTasks();
    }

    public void goToHomeActivity(View view){
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    public void goToEditTaskActivity(View view){
        Intent intent = new Intent(this, EditTaskActivity.class);
        intent.putExtra("taskId", task.getId());
        startActivity(intent);
    }

    public void updateTasks() {
        tasks.clear();
        List<ScheduledTask> newTasks = getTasks();
        if (newTasks.isEmpty()) {
            notFoundTv.setVisibility(View.VISIBLE);
        } else {
            notFoundTv.setVisibility(View.GONE);
        }
        tasks.addAll(newTasks);
        recyclerView.getAdapter().notifyDataSetChanged();
    }

    public List<ScheduledTask> getTasks() {
        List<Integer> idList = Arrays.asList(task.getId());
        return ScheduledTask.getByTaskIds(this, idList, true);
    }

    protected void onResume() {
        super.onResume();
        updateTasks();
    }

    public void finish(View view) {
        finish();
    }
}
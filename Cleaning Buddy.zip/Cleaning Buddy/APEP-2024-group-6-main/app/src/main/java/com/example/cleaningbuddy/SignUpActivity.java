package com.example.cleaningbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import models.User;
import validation.PasswordValidator;
import validation.StringValidator;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_up);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void goToHomeActivity(View view) {
        EditText userNameEditText = findViewById(R.id.signUp_username_pt_id);
        String userNameInput = userNameEditText.getText().toString();

        if (!validateUserName(userNameInput)) return;

        if (validateUniqueUser(userNameInput)) return;

        EditText passwordEditText = findViewById(R.id.signUp_password_et_id);
        EditText passWordConfirmEditText = findViewById(R.id.signUp_confirmPassword_et_id);
        String passwordInput = passwordEditText.getText().toString();
        String passWordConfirmInput = passWordConfirmEditText.getText().toString();

        if(!validatePasswords(passwordInput, passWordConfirmInput, passWordConfirmEditText,
                passWordConfirmEditText)) return;

        String hashedPassword = PasswordValidator.hashPassword(passwordInput);
        User user = new User(userNameInput, hashedPassword);
        User.addUser(this, user);

        User.setCurrentUser(User.getUserFromDb(this, userNameInput));

        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);

    }

    private boolean validateUserName(String username) {
        if (!StringValidator.isNotNullOrEmpty(username)) {
            showToast(getString(R.string.nameEmpty_toast_id));
            return false;
        }
        if (!StringValidator.isLengthBetween(username, 5, 15)) {
            showToast(getString(R.string.nameLength_toast_id));
            return false;
        }
        return true;
    }

    private boolean validateUniqueUser(String username) {
        boolean exists = User.doesUserExist(this, username);

        if (exists) {
            showToast(getString(R.string.duplicateUsername_toast_id));
        }
        return exists;
    }

    private boolean validatePasswords(String password, String confirmPassword, EditText passwordEditText,
                                      EditText confirmPasswordEditText) {
        if (StringValidator.StringInputNotEqual(password, confirmPassword)) {
            showToast(getString(R.string.passwordsDifferent_toast_id));
            passwordEditText.setText("");
            confirmPasswordEditText.setText("");
            return false;
        }

        if (!StringValidator.isLengthBetween(password, 5, 25)) {
            showToast(getString(R.string.passwordLength_toast_id));
            passwordEditText.setText("");
            confirmPasswordEditText.setText("");
            return false;
        }
        return true;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public void goToLogInActivity(View view) {
        Intent intent = new Intent(this, LogInActivity.class);
        startActivity(intent);
    }

}
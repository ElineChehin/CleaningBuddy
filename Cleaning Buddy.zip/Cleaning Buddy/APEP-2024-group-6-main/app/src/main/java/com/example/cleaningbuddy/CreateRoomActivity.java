package com.example.cleaningbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import models.Room;
import validation.StringValidator;

public class CreateRoomActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_room);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void goToHomeActivity(View view){
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    public void save(View view){
        EditText nameET = findViewById(R.id.createRoom_name_pt_id);
        String nameString = nameET.getText().toString();

        if (!StringValidator.isNotNullOrEmpty(nameString)){
            Toast.makeText(this, getString(R.string.nameEmpty_toast_id), Toast.LENGTH_SHORT).show();
            return;
        }
        if (!StringValidator.isLengthBetween(nameString, 1, 30)){
            Toast.makeText(this, getString(R.string.nameLength_toast_id), Toast.LENGTH_SHORT).show();
            return;
        }

        Room room = new Room(nameString);
        Room.add(this, room);
        finish();
    }

    public void finish(View view){
        finish();
    }
}